<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "techshop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $customerName = $_POST['customerName'];
    $customerMobile = $_POST['customerMobile'];
    $customerPassword = password_hash($_POST['customerPassword'], PASSWORD_BCRYPT); // Encrypt password
    $customerAddress = $_POST['customerAddress'];

    // Insert customer into the database
    $sql = "INSERT INTO customer (customer_name, customer_mobile, customer_password, customer_address) 
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $customerName, $customerMobile, $customerPassword, $customerAddress);

    if ($stmt->execute()) {
        echo "<script>alert('Customer registered successfully!'); window.location.href='../index2.php';</script>";
    } else {
        echo "<script>alert('Error registering customer: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Registration</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Customer Registration</h2>
        <form method="POST">
            <!-- Customer Name -->
            <div class="mb-3">
                <label for="customerName" class="form-label">Name</label>
                <input type="text" class="form-control" id="customerName" name="customerName" placeholder="Enter your name" required>
            </div>

            <!-- Mobile Number -->
            <div class="mb-3">
                <label for="customerMobile" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="customerMobile" name="customerMobile" placeholder="Enter your mobile number" required>
            </div>

            <!-- Password -->
            <div class="mb-3">
                <label for="customerPassword" class="form-label">Password</label>
                <input type="password" class="form-control" id="customerPassword" name="customerPassword" placeholder="Enter your password" required>
            </div>

            <!-- Address -->
            <div class="mb-3">
                <label for="customerAddress" class="form-label">Address</label>
                <textarea class="form-control" id="customerAddress" name="customerAddress" rows="3" placeholder="Enter your address" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Register</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>