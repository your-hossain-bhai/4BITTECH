<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Store Navbar -->
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="../images/logo.png" alt="Store Logo" width="150" height="150" class="d-inline-block align-text-top">
                4 Bit Tech
            </a>
            <span class="navbar-text">
                Admin: <span id="admin-name">[Admin Name]</span>
            </span>
        </div>
    </nav>

    <!-- Admin Panel Heading -->
    <div class="container mt-3">
        <h1>Admin Panel</h1>
    </div>

    <!-- Main Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index2.php">4 Bit Tech</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?insert_category">Insert Category</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?insert_brand">Insert Brand</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?insert_product">Insert Product</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?view_all_product">View All Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?view_by_category">View by Category</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?delete_product">Delete Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">All Orders</a>
                    </li>
                    <!-- Add additional buttons -->
                    <li class="nav-item">
                        <a class="nav-link" href="#">Button 7</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Button 8</a>
                    
                </ul>
            </div>
        </div>
    </nav>

    <!-- Content Section -->
    <div class="container">
        <?php
        if (isset($_GET['insert_product'])) {
            include('insert_product.php');
        }
        ?>
    </div>

    <div class="container">
        <?php
        if (isset($_GET['insert_category'])) {
            include('insert_category.php');
        }
        ?>
    </div>

    <div class="container">
        <?php
        if (isset($_GET['insert_brand'])) {
            include('insert_brand.php');
        }
        ?>
    </div>

    <div class="container">
        <?php
        if (isset($_GET['view_all_product'])) {
            include('view_all_product.php');
        }
        ?>
    </div>

    <div class="container">
        <?php
        if (isset($_GET['view_by_category'])) {
            include('view_by_category.php');
        }
        ?>
    </div>

    <div class="container">
        <?php
        if (isset($_GET['delete_product'])) {
            include('delete_product.php');
        }
        ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
