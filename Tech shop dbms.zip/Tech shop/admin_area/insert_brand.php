<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Brand</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php
include('../includes/connect.php'); 
if(isset($_POST['insert_br'])){
    $brand_name=$_POST['brandName'];
    // select data from database
    $select_query="Select * from `brand` where brand_name='$brand_name'"; 
    $result_select=mysqli_query($con, $select_query); 
    $number=mysqli_num_rows($result_select);
    if($number>0){
        echo "<script>alert('This Brand is present inside the database')</script>"; 
    }
    else{
        $insert_query="insert into `brand` (brand_name) values ('$brand_name')"; 
        $result=mysqli_query($con, $insert_query);
        if($result) {
                echo "<script>alert('This Brand is inserted successfully')</script>"; 
        }

    }
}
?>
    <div class="container mt-5">
        <h2>Insert Brand</h2>
        <form method="POST" action="insert_brand.php">
            <!-- Brand Name -->
            <div class="mb-3">
                <label for="brandName" class="form-label">Brand Name</label>
                <input type="text" class="form-control" id="brandName" name="brandName" placeholder="Enter brand name" required>
            </div>

            <!-- Brand Description 
            <div class="mb-3">
                <label for="brandDescription" class="form-label">Brand Description</label>
                <textarea class="form-control" id="brandDescription" name="brandDescription" rows="3" placeholder="Enter brand description" required></textarea>
            </div>-->

            <button type="submit" class="btn btn-primary" name="insert_br">Insert Brand</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
