<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "techshop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all categories from the database
$categories = [];
$sql = "SELECT DISTINCT product_category FROM product";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['product_category'];
    }
}

// Fetch products based on selected category
$products = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category'])) {
    $selectedCategory = $_POST['category'];

    $stmt = $conn->prepare("SELECT * FROM product WHERE product_category = ?");
    $stmt->bind_param("s", $selectedCategory);
    $stmt->execute();
    $productsResult = $stmt->get_result();

    while ($row = $productsResult->fetch_assoc()) {
        $products[] = $row;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products by Category</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>View Products by Category</h2>

        <!-- Category Selection Form -->
        <form method="POST" class="mb-4">
            <div class="mb-3">
                <label for="category" class="form-label">Select Category</label>
                <select class="form-select" id="category" name="category" required>
                    <option selected disabled value="">Choose a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars($category) ?>">
                            <?= htmlspecialchars($category) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">View Products</button>
        </form>

        <!-- Display Products -->
        <?php if (!empty($products)): ?>
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Image 1</th>
                        <th>Image 2</th>
                        <th>Keywords</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['product_id']) ?></td>
                            <td><?= htmlspecialchars($product['product_name']) ?></td>
                            <td><?= htmlspecialchars($product['product_category']) ?></td>
                            <td><?= htmlspecialchars($product['quantity']) ?></td>
                            <td><?= htmlspecialchars($product['price']) ?></td>
                            <td><?= nl2br(htmlspecialchars($product['description'])) ?></td>
                            <td>
                                <?php if ($product['image_1']): ?>
                                    <img src="uploads/<?= htmlspecialchars($product['image_1']) ?>" alt="Image 1" width="100">
                                <?php else: ?>
                                    No image
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($product['image_2']): ?>
                                    <img src="uploads/<?= htmlspecialchars($product['image_2']) ?>" alt="Image 2" width="100">
                                <?php else: ?>
                                    No image
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($product['keywords']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <p>No products found in the selected category.</p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
