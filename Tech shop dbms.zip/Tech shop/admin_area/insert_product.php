<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "techshop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $productName = $_POST['productName'];
    $productCategory = $_POST['productCategory'];
    $productQuantity = $_POST['productQuantity'];
    $productPrice = $_POST['productPrice'];
    $productDescription = $_POST['productDescription'];
    $productKeywords = $_POST['productKeywords'];

    // Handle file uploads
    $image1 = $_FILES['productPicture1']['name'];
    $image2 = $_FILES['productPicture2']['name'];

    $targetDir = "uploads/";
    $targetFile1 = $targetDir . basename($image1);
    $targetFile2 = $targetDir . basename($image2);

    move_uploaded_file($_FILES['productPicture1']['tmp_name'], $targetFile1);
    if ($image2) {
        move_uploaded_file($_FILES['productPicture2']['tmp_name'], $targetFile2);
    }

    // Insert product into the database
    $sql = "INSERT INTO product (product_name, product_category, quantity, price, description, image_1, image_2, keywords) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssss", $productName, $productCategory, $productQuantity, $productPrice, $productDescription, $image1, $image2, $productKeywords);

    if ($stmt->execute()) {
        echo "<script>alert('Product inserted successfully!'); window.location.href='index2.php';</script>";
    } else {
        echo "<script>alert('Error inserting product: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}

// Fetch categories from the database
$categories = [];
$sql = "SELECT category_id, category_name FROM category";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Insert Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <!-- Product Name -->
            <div class="mb-3">
                <label for="productName" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="productName" name="productName" placeholder="Enter product name" required>
            </div>

            <!-- Product Category -->
            <div class="mb-3">
                <label for="productCategory" class="form-label">Category</label>
                <select class="form-select" id="productCategory" name="productCategory" required>
                    <option selected disabled value="">Choose a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['category_name'] ?>">
                            <?= $category['category_name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Product Quantity -->
            <div class="mb-3">
                <label for="productQuantity" class="form-label">Quantity</label>
                <input type="number" class="form-control" id="productQuantity" name="productQuantity" placeholder="Enter product quantity" required>
            </div>

            <!-- Product Price -->
            <div class="mb-3">
                <label for="productPrice" class="form-label">Price</label>
                <input type="number" class="form-control" id="productPrice" name="productPrice" placeholder="Enter product price" required>
            </div>

            <!-- Product Description -->
            <div class="mb-3">
                <label for="productDescription" class="form-label">Description</label>
                <textarea class="form-control" id="productDescription" name="productDescription" rows="3" placeholder="Enter product description" required></textarea>
            </div>

            <!-- Product Picture 1 -->
            <div class="mb-3">
                <label for="productPicture1" class="form-label">Product Picture 1</label>
                <input type="file" class="form-control" id="productPicture1" name="productPicture1" accept="image/*" required>
            </div>

            <!-- Product Picture 2 -->
            <div class="mb-3">
                <label for="productPicture2" class="form-label">Product Picture 2</label>
                <input type="file" class="form-control" id="productPicture2" name="productPicture2" accept="image/*">
            </div>

            <!-- Product Keywords -->
            <div class="mb-3">
                <label for="productKeywords" class="form-label">Product Keywords</label>
                <input type="text" class="form-control" id="productKeywords" name="productKeywords" placeholder="Enter keywords separated by commas" required>
            </div>

            <button type="submit" class="btn btn-primary">Insert Product</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
