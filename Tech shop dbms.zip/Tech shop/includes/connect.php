<?php

$con=mysqli_connect('localhost','root','','techshop');
if(!$con){
    die(mysqli_error($con));
}


?>